import { useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'

interface GlassCardProps {
  children: React.ReactNode
  className?: string
  accent?: 'gold' | 'cyan' | 'none'
  intensity?: number
}

export default function GlassCard({ children, className = '', accent = 'none', intensity = 10 }: GlassCardProps) {
  const ref = useRef<HTMLDivElement>(null)

  const x = useMotionValue(0)
  const y = useMotionValue(0)

  const springConfig = { damping: 20, stiffness: 300 }
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [intensity, -intensity]), springConfig)
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-intensity, intensity]), springConfig)

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return
    const rect = ref.current.getBoundingClientRect()
    const centerX = rect.left + rect.width / 2
    const centerY = rect.top + rect.height / 2
    const mouseX = (e.clientX - centerX) / rect.width
    const mouseY = (e.clientY - centerY) / rect.height
    x.set(mouseX)
    y.set(mouseY)
  }

  const handleMouseLeave = () => {
    x.set(0)
    y.set(0)
  }

  const borderColor = accent === 'gold'
    ? 'rgba(212, 168, 67, 0.2)'
    : accent === 'cyan'
    ? 'rgba(0, 229, 255, 0.2)'
    : 'rgba(255, 255, 255, 0.08)'

  const bgColor = accent === 'gold'
    ? 'rgba(10, 8, 4, 0.85)'
    : accent === 'cyan'
    ? 'rgba(4, 10, 12, 0.85)'
    : 'rgba(8, 8, 14, 0.82)'

  return (
    <motion.div
      ref={ref}
      className={`relative ${className}`}
      style={{
        background: bgColor,
        backdropFilter: 'blur(24px) saturate(1.2)',
        WebkitBackdropFilter: 'blur(24px) saturate(1.2)',
        border: `1px solid ${borderColor}`,
        borderRadius: 16,
        transformStyle: 'preserve-3d',
        perspective: 1000,
        rotateX,
        rotateY,
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255,255,255,0.05)',
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      whileHover={{
        boxShadow:
          accent === 'gold'
            ? '0 12px 40px rgba(212, 168, 67, 0.12), inset 0 1px 0 rgba(255,255,255,0.08)'
            : accent === 'cyan'
            ? '0 12px 40px rgba(0, 229, 255, 0.12), inset 0 1px 0 rgba(255,255,255,0.08)'
            : '0 12px 40px rgba(255, 255, 255, 0.06), inset 0 1px 0 rgba(255,255,255,0.08)',
      }}
      transition={{ duration: 0.3 }}
    >
      {/* Glare effect */}
      <motion.div
        className="absolute inset-0 pointer-events-none rounded-2xl overflow-hidden"
        style={{
          background: useTransform(
            [x, y],
            ([latestX, latestY]) =>
              `radial-gradient(circle at ${(Number(latestX) + 0.5) * 100}% ${(Number(latestY) + 0.5) * 100}%, rgba(255,255,255,0.06), transparent 60%)`
          ),
        }}
      />
      <div className="relative z-10">{children}</div>
    </motion.div>
  )
}
