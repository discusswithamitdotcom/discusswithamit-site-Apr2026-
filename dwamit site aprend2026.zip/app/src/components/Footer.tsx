import { Linkedin, Mail, MapPin, Phone, ArrowUpRight } from 'lucide-react'
import { Link } from 'react-router-dom'

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/about', label: 'About' },
  { path: '/experience', label: 'Experience' },
  { path: '/skills', label: 'Skills' },
  { path: '/contact', label: 'Contact' },
]

export default function Footer() {
  return (
    <footer
      className="relative z-10 w-full"
      style={{
        borderTop: '1px solid rgba(255, 255, 255, 0.06)',
        background: 'rgba(8, 8, 12, 0.95)',
        backdropFilter: 'blur(20px)',
      }}
    >
      <div className="max-w-[1200px] mx-auto px-6 py-12">
        {/* Top section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
          {/* Brand */}
          <div>
            <h3
              className="text-xl font-bold mb-3"
              style={{ color: '#d4a843', textShadow: '0 0 12px rgba(212,168,67,0.2)' }}
            >
              Amit Sharma
            </h3>
            <p className="text-sm leading-relaxed mb-4" style={{ color: 'rgba(245, 240, 232, 0.6)' }}>
              Swiss Army Knife of FinTech & Crypto.
              9+ years building products, scaling operations, and forging alliances across the globe.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://www.linkedin.com/in/amit-sharma-international-fintech/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
                style={{
                  background: 'rgba(212, 168, 67, 0.1)',
                  border: '1px solid rgba(212, 168, 67, 0.2)',
                  color: '#d4a843',
                }}
                aria-label="LinkedIn"
              >
                <Linkedin size={16} />
              </a>
              <a
                href="mailto:amit@example.com"
                className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
                style={{
                  background: 'rgba(212, 168, 67, 0.1)',
                  border: '1px solid rgba(212, 168, 67, 0.2)',
                  color: '#d4a843',
                }}
                aria-label="Email"
              >
                <Mail size={16} />
              </a>
              <a
                href="https://wa.me/971503855067?text=Hello"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
                style={{
                  background: 'rgba(37, 211, 102, 0.1)',
                  border: '1px solid rgba(37, 211, 102, 0.2)',
                  color: '#25D366',
                }}
                aria-label="WhatsApp"
              >
                <Phone size={16} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4
              className="text-xs uppercase tracking-widest font-semibold mb-4"
              style={{ color: 'rgba(245, 240, 232, 0.4)' }}
            >
              Quick Links
            </h4>
            <ul className="space-y-2.5">
              {navLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="group inline-flex items-center gap-1.5 text-sm transition-colors duration-300 hover:text-[#d4a843]"
                    style={{ color: 'rgba(245, 240, 232, 0.6)' }}
                  >
                    {link.label}
                    <ArrowUpRight
                      size={12}
                      className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      style={{ color: '#d4a843' }}
                    />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4
              className="text-xs uppercase tracking-widest font-semibold mb-4"
              style={{ color: 'rgba(245, 240, 232, 0.4)' }}
            >
              Get in Touch
            </h4>
            <div className="space-y-3">
              <a
                href="https://wa.me/971503855067?text=Hello"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-sm transition-colors duration-300 hover:text-[#d4a843]"
                style={{ color: 'rgba(245, 240, 232, 0.6)' }}
              >
                <Phone size={14} style={{ color: '#25D366' }} />
                +971 50 385 5067
              </a>
              <a
                href="https://www.linkedin.com/in/amit-sharma-international-fintech/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-sm transition-colors duration-300 hover:text-[#d4a843]"
                style={{ color: 'rgba(245, 240, 232, 0.6)' }}
              >
                <Linkedin size={14} style={{ color: '#0077B5' }} />
                LinkedIn Profile
              </a>
              <div
                className="flex items-center gap-2.5 text-sm"
                style={{ color: 'rgba(245, 240, 232, 0.6)' }}
              >
                <MapPin size={14} style={{ color: '#00e5ff' }} />
                Dubai, UAE
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px mb-6" style={{ background: 'linear-gradient(to right, transparent, rgba(255,255,255,0.06), transparent)' }} />

        {/* Bottom bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs" style={{ color: 'rgba(245, 240, 232, 0.35)' }}>
            &copy; {new Date().getFullYear()} Amit Sharma. All rights reserved.
          </div>
          <div
            className="text-xs italic"
            style={{ color: 'rgba(245, 240, 232, 0.3)' }}
          >
            "Building the future of finance, one product at a time."
          </div>
        </div>
      </div>
    </footer>
  )
}
