import { useEffect, useRef } from 'react'
import * as THREE from 'three'

function createGlowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas')
  canvas.width = 64
  canvas.height = 64
  const ctx = canvas.getContext('2d')!
  const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
  gradient.addColorStop(0, 'rgba(255, 255, 255, 1)')
  gradient.addColorStop(0.3, 'rgba(255, 255, 255, 0.6)')
  gradient.addColorStop(0.6, 'rgba(255, 255, 255, 0.15)')
  gradient.addColorStop(1, 'rgba(255, 255, 255, 0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, 64, 64)
  return new THREE.CanvasTexture(canvas)
}

export default function HomeBackground() {
  const containerRef = useRef<HTMLDivElement>(null)
  const mouseRef = useRef({ x: 0, y: 0, active: false })

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const scene = new THREE.Scene()
    scene.fog = new THREE.FogExp2(0x0a0a0f, 0.008)

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.z = 60

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    container.appendChild(renderer.domElement)

    const glowTexture = createGlowTexture()
    const particleCount = 900

    const geometry = new THREE.BufferGeometry()
    const positions = new Float32Array(particleCount * 3)
    const colors = new Float32Array(particleCount * 3)
    const sizes = new Float32Array(particleCount)
    const particlesData: { velocity: THREE.Vector3; originalPos: THREE.Vector3; phase: number }[] = []

    for (let i = 0; i < particleCount; i++) {
      const radius = 25 + Math.random() * 50
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta)
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta)
      positions[i * 3 + 2] = radius * Math.cos(phi)

      const colorChoice = Math.random()
      let r: number, g: number, b: number
      if (colorChoice < 0.5) {
        r = 0.83 + (Math.random() - 0.5) * 0.1
        g = 0.66 + (Math.random() - 0.5) * 0.1
        b = 0.26 + (Math.random() - 0.5) * 0.1
      } else if (colorChoice < 0.8) {
        r = 0.94 + (Math.random() - 0.5) * 0.1
        g = 0.78 + (Math.random() - 0.5) * 0.1
        b = 0.42 + (Math.random() - 0.5) * 0.1
      } else {
        r = 0.0 + (Math.random() - 0.5) * 0.05
        g = 0.90 + (Math.random() - 0.5) * 0.1
        b = 1.0 + (Math.random() - 0.5) * 0.1
      }
      colors[i * 3] = Math.max(0, Math.min(1, r))
      colors[i * 3 + 1] = Math.max(0, Math.min(1, g))
      colors[i * 3 + 2] = Math.max(0, Math.min(1, b))

      sizes[i] = 2 * (0.5 + Math.random() * 0.8)
      particlesData.push({
        velocity: new THREE.Vector3((Math.random() - 0.5) * 0.015, (Math.random() - 0.5) * 0.015, (Math.random() - 0.5) * 0.015),
        originalPos: new THREE.Vector3(positions[i * 3], positions[i * 3 + 1], positions[i * 3 + 2]),
        phase: Math.random() * Math.PI * 2,
      })
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1))

    const material = new THREE.PointsMaterial({
      size: 2, vertexColors: true, transparent: true, opacity: 0.7,
      sizeAttenuation: true, map: glowTexture, blending: THREE.AdditiveBlending, depthWrite: false,
    })

    const points = new THREE.Points(geometry, material)
    scene.add(points)

    const lineMaterial = new THREE.LineBasicMaterial({ color: 0xd4a843, transparent: true, opacity: 0.04, blending: THREE.AdditiveBlending, depthWrite: false })
    let linesMesh: THREE.LineSegments | null = null
    const maxDistance = 20
    const maxConnections = 2

    function updateConnections() {
      if (linesMesh) { scene.remove(linesMesh); linesMesh.geometry.dispose() }
      const linePositions: number[] = []
      const posArray = geometry.attributes.position.array as Float32Array
      for (let i = 0; i < particleCount; i++) {
        let connections = 0
        for (let j = i + 1; j < particleCount; j++) {
          if (connections >= maxConnections) break
          const dx = posArray[i * 3] - posArray[j * 3]
          const dy = posArray[i * 3 + 1] - posArray[j * 3 + 1]
          const dz = posArray[i * 3 + 2] - posArray[j * 3 + 2]
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz)
          if (dist < maxDistance) {
            linePositions.push(posArray[i * 3], posArray[i * 3 + 1], posArray[i * 3 + 2], posArray[j * 3], posArray[j * 3 + 1], posArray[j * 3 + 2])
            connections++
          }
        }
      }
      if (linePositions.length > 0) {
        const lineGeometry = new THREE.BufferGeometry()
        lineGeometry.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3))
        linesMesh = new THREE.LineSegments(lineGeometry, lineMaterial)
        scene.add(linesMesh)
      }
    }

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1
      mouseRef.current.active = true
    }
    const handleMouseLeave = () => { mouseRef.current.active = false }
    window.addEventListener('mousemove', handleMouseMove, { passive: true })
    window.addEventListener('mouseleave', handleMouseLeave, { passive: true })

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', handleResize, { passive: true })

    let animationId: number
    let time = 0
    let frameCount = 0

    const animate = () => {
      animationId = requestAnimationFrame(animate)
      time += 0.005
      frameCount++
      if (frameCount % 3 === 0) updateConnections()

      const posArray = geometry.attributes.position.array as Float32Array
      const sizeArray = geometry.attributes.size.array as Float32Array
      camera.rotation.x += (mouseRef.current.y * 0.015 - camera.rotation.x) * 0.05
      camera.rotation.y += (mouseRef.current.x * 0.015 - camera.rotation.y) * 0.05
      const mouseWorldX = mouseRef.current.x * 40
      const mouseWorldY = mouseRef.current.y * 40

      for (let i = 0; i < particleCount; i++) {
        const px = posArray[i * 3]
        const py = posArray[i * 3 + 1]
        const pz = posArray[i * 3 + 2]
        posArray[i * 3] += particlesData[i].velocity.x + Math.sin(time + particlesData[i].phase) * 0.003
        posArray[i * 3 + 1] += particlesData[i].velocity.y + Math.cos(time * 0.7 + particlesData[i].phase) * 0.003
        posArray[i * 3 + 2] += particlesData[i].velocity.z + Math.sin(time * 0.5 + particlesData[i].phase) * 0.002

        if (mouseRef.current.active) {
          const dx = mouseWorldX - px
          const dy = mouseWorldY - py
          const dist2D = Math.sqrt(dx * dx + dy * dy)
          if (dist2D < 20 && dist2D > 0.1) {
            const force = (20 - dist2D) / 20 * 0.015
            posArray[i * 3] += (dx / dist2D) * force
            posArray[i * 3 + 1] += (dy / dist2D) * force
          }
          if (dist2D < 25) {
            const pulse = (1 - dist2D / 25) * 1.5
            sizeArray[i] = 2 * (0.5 + Math.sin(time * 3 + particlesData[i].phase) * 0.3 + pulse)
          } else {
            sizeArray[i] = 2 * (0.5 + Math.sin(time * 2 + particlesData[i].phase) * 0.2)
          }
        } else {
          sizeArray[i] = 2 * (0.5 + Math.sin(time * 2 + particlesData[i].phase) * 0.2)
        }
        const distFromOrigin = Math.sqrt(px * px + py * py + pz * pz)
        if (distFromOrigin > 80) {
          const orig = particlesData[i].originalPos
          posArray[i * 3] += (orig.x - px) * 0.008
          posArray[i * 3 + 1] += (orig.y - py) * 0.008
          posArray[i * 3 + 2] += (orig.z - pz) * 0.008
        }
      }
      geometry.attributes.position.needsUpdate = true
      geometry.attributes.size.needsUpdate = true
      renderer.render(scene, camera)
    }
    animate()

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseleave', handleMouseLeave)
      window.removeEventListener('resize', handleResize)
      geometry.dispose(); material.dispose(); glowTexture.dispose(); lineMaterial.dispose()
      if (linesMesh) linesMesh.geometry.dispose()
      renderer.dispose()
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement)
    }
  }, [])

  return (
    <div ref={containerRef} style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, pointerEvents: 'none' }} />
  )
}
