import { useEffect, useRef } from 'react'
import * as THREE from 'three'

function createGlowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas')
  canvas.width = 128
  canvas.height = 128
  const ctx = canvas.getContext('2d')!
  const gradient = ctx.createRadialGradient(64, 64, 0, 64, 64, 64)
  gradient.addColorStop(0, 'rgba(255, 255, 255, 1)')
  gradient.addColorStop(0.2, 'rgba(255, 255, 255, 0.5)')
  gradient.addColorStop(0.5, 'rgba(255, 255, 255, 0.1)')
  gradient.addColorStop(1, 'rgba(255, 255, 255, 0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, 128, 128)
  return new THREE.CanvasTexture(canvas)
}

export default function AboutBackground() {
  const containerRef = useRef<HTMLDivElement>(null)
  const mouseRef = useRef({ x: 0, y: 0, active: false })

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.z = 50

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    container.appendChild(renderer.domElement)

    const glowTexture = createGlowTexture()

    // Two particle layers: small sparkles + larger bokeh orbs
    const sparkleCount = 400
    const bokehCount = 60

    // Sparkles
    const sGeo = new THREE.BufferGeometry()
    const sPos = new Float32Array(sparkleCount * 3)
    const sColors = new Float32Array(sparkleCount * 3)
    const sSizes = new Float32Array(sparkleCount)
    const sData: { speed: number; phase: number }[] = []

    for (let i = 0; i < sparkleCount; i++) {
      sPos[i * 3] = (Math.random() - 0.5) * 100
      sPos[i * 3 + 1] = (Math.random() - 0.5) * 60
      sPos[i * 3 + 2] = (Math.random() - 0.5) * 30

      const isCyan = Math.random() > 0.55
      sColors[i * 3] = isCyan ? 0.0 + Math.random() * 0.1 : 0.83 + (Math.random() - 0.5) * 0.1
      sColors[i * 3 + 1] = isCyan ? 0.9 + Math.random() * 0.1 : 0.66 + (Math.random() - 0.5) * 0.1
      sColors[i * 3 + 2] = isCyan ? 1.0 : 0.26 + (Math.random() - 0.5) * 0.1

      sSizes[i] = 1.5 + Math.random() * 2
      sData.push({ speed: 0.003 + Math.random() * 0.008, phase: Math.random() * Math.PI * 2 })
    }

    sGeo.setAttribute('position', new THREE.BufferAttribute(sPos, 3))
    sGeo.setAttribute('color', new THREE.BufferAttribute(sColors, 3))
    sGeo.setAttribute('size', new THREE.BufferAttribute(sSizes, 1))

    const sMat = new THREE.PointsMaterial({
      size: 2, vertexColors: true, transparent: true, opacity: 0.6,
      sizeAttenuation: true, map: glowTexture, blending: THREE.AdditiveBlending, depthWrite: false,
    })
    const sparkles = new THREE.Points(sGeo, sMat)
    scene.add(sparkles)

    // Bokeh orbs (larger, softer, slower)
    const bGeo = new THREE.BufferGeometry()
    const bPos = new Float32Array(bokehCount * 3)
    const bColors = new Float32Array(bokehCount * 3)
    const bSizes = new Float32Array(bokehCount)
    const bData: { speedY: number; speedX: number; phase: number }[] = []

    for (let i = 0; i < bokehCount; i++) {
      bPos[i * 3] = (Math.random() - 0.5) * 90
      bPos[i * 3 + 1] = (Math.random() - 0.5) * 55
      bPos[i * 3 + 2] = (Math.random() - 0.5) * 25

      const isGold = Math.random() > 0.4
      bColors[i * 3] = isGold ? 0.83 : 0.0
      bColors[i * 3 + 1] = isGold ? 0.66 : 0.88
      bColors[i * 3 + 2] = isGold ? 0.26 : 1.0

      bSizes[i] = 8 + Math.random() * 12
      bData.push({ speedY: 0.001 + Math.random() * 0.003, speedX: (Math.random() - 0.5) * 0.002, phase: Math.random() * Math.PI * 2 })
    }

    bGeo.setAttribute('position', new THREE.BufferAttribute(bPos, 3))
    bGeo.setAttribute('color', new THREE.BufferAttribute(bColors, 3))
    bGeo.setAttribute('size', new THREE.BufferAttribute(bSizes, 1))

    const bMat = new THREE.PointsMaterial({
      size: 12, vertexColors: true, transparent: true, opacity: 0.15,
      sizeAttenuation: true, map: glowTexture, blending: THREE.AdditiveBlending, depthWrite: false,
    })
    const bokeh = new THREE.Points(bGeo, bMat)
    scene.add(bokeh)

    // Mouse tracking
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1
      mouseRef.current.active = true
    }
    const handleMouseLeave = () => { mouseRef.current.active = false }
    window.addEventListener('mousemove', handleMouseMove, { passive: true })
    window.addEventListener('mouseleave', handleMouseLeave, { passive: true })

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', handleResize, { passive: true })

    let animationId: number
    let time = 0

    const animate = () => {
      animationId = requestAnimationFrame(animate)
      time += 0.008

      const sArr = sGeo.attributes.position.array as Float32Array
      const sSizeArr = sGeo.attributes.size.array as Float32Array
      const mouseWorldX = mouseRef.current.x * 40
      const mouseWorldY = mouseRef.current.y * 25

      for (let i = 0; i < sparkleCount; i++) {
        // Gentle drift
        sArr[i * 3] += Math.sin(time + sData[i].phase) * 0.003
        sArr[i * 3 + 1] += sData[i].speed + Math.cos(time * 0.5 + sData[i].phase) * 0.002
        sArr[i * 3 + 2] += Math.sin(time * 0.3 + sData[i].phase) * 0.001

        // Cursor scatter
        if (mouseRef.current.active) {
          const dx = sArr[i * 3] - mouseWorldX
          const dy = sArr[i * 3 + 1] - mouseWorldY
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < 18 && dist > 0.1) {
            const force = (18 - dist) / 18 * 0.06
            sArr[i * 3] += (dx / dist) * force
            sArr[i * 3 + 1] += (dy / dist) * force
            sSizeArr[i] = (1.5 + sData[i].phase % 2) * (1 + (18 - dist) / 18)
          } else {
            sSizeArr[i] = 1.5 + sData[i].phase % 2
          }
        }

        // Wrap vertically
        if (sArr[i * 3 + 1] > 35) sArr[i * 3 + 1] = -35
        if (sArr[i * 3 + 1] < -35) sArr[i * 3 + 1] = 35
      }
      sGeo.attributes.position.needsUpdate = true
      sGeo.attributes.size.needsUpdate = true

      // Bokeh slow drift
      const bArr = bGeo.attributes.position.array as Float32Array
      for (let i = 0; i < bokehCount; i++) {
        bArr[i * 3] += bData[i].speedX + Math.sin(time * 0.2 + bData[i].phase) * 0.002
        bArr[i * 3 + 1] += bData[i].speedY
        bArr[i * 3 + 2] += Math.cos(time * 0.15 + bData[i].phase) * 0.001

        if (bArr[i * 3 + 1] > 32) { bArr[i * 3 + 1] = -32; bArr[i * 3] = (Math.random() - 0.5) * 90 }
      }
      bGeo.attributes.position.needsUpdate = true

      // Gentle camera sway
      camera.position.x += (mouseRef.current.x * 2 - camera.position.x) * 0.02
      camera.position.y += (mouseRef.current.y * 1 - camera.position.y) * 0.02

      renderer.render(scene, camera)
    }
    animate()

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseleave', handleMouseLeave)
      window.removeEventListener('resize', handleResize)
      sGeo.dispose(); sMat.dispose(); bGeo.dispose(); bMat.dispose(); glowTexture.dispose()
      renderer.dispose()
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement)
    }
  }, [])

  return <div ref={containerRef} style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, pointerEvents: 'none' }} />
}
