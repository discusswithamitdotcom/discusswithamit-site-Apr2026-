import { useEffect, useRef } from 'react'
import * as THREE from 'three'

function createGlowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas')
  canvas.width = 128
  canvas.height = 128
  const ctx = canvas.getContext('2d')!
  const gradient = ctx.createRadialGradient(64, 64, 0, 64, 64, 64)
  gradient.addColorStop(0, 'rgba(255, 255, 255, 1)')
  gradient.addColorStop(0.2, 'rgba(255, 255, 255, 0.5)')
  gradient.addColorStop(0.5, 'rgba(255, 255, 255, 0.1)')
  gradient.addColorStop(1, 'rgba(255, 255, 255, 0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, 128, 128)
  return new THREE.CanvasTexture(canvas)
}

export default function ExperienceBackground() {
  const containerRef = useRef<HTMLDivElement>(null)
  const mouseRef = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.z = 55

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    container.appendChild(renderer.domElement)

    const glowTexture = createGlowTexture()

    // Main starfield particles
    const starCount = 500
    const starGeo = new THREE.BufferGeometry()
    const starPos = new Float32Array(starCount * 3)
    const starColors = new Float32Array(starCount * 3)
    const starSizes = new Float32Array(starCount)
    const starData: { driftX: number; driftY: number; driftZ: number; phase: number; twinkleSpeed: number }[] = []

    for (let i = 0; i < starCount; i++) {
      starPos[i * 3] = (Math.random() - 0.5) * 100
      starPos[i * 3 + 1] = (Math.random() - 0.5) * 60
      starPos[i * 3 + 2] = (Math.random() - 0.5) * 30

      // Colors: purple, gold, cyan, white
      const colorRoll = Math.random()
      if (colorRoll < 0.3) {
        starColors[i * 3] = 0.65 + Math.random() * 0.15
        starColors[i * 3 + 1] = 0.33 + Math.random() * 0.1
        starColors[i * 3 + 2] = 0.97
      } else if (colorRoll < 0.55) {
        starColors[i * 3] = 0.83
        starColors[i * 3 + 1] = 0.66
        starColors[i * 3 + 2] = 0.26
      } else if (colorRoll < 0.8) {
        starColors[i * 3] = 0.0
        starColors[i * 3 + 1] = 0.9
        starColors[i * 3 + 2] = 1.0
      } else {
        starColors[i * 3] = 0.9 + Math.random() * 0.1
        starColors[i * 3 + 1] = 0.9 + Math.random() * 0.1
        starColors[i * 3 + 2] = 0.95
      }

      starSizes[i] = 1.2 + Math.random() * 2.5
      starData.push({
        driftX: (Math.random() - 0.5) * 0.004,
        driftY: (Math.random() - 0.5) * 0.004,
        driftZ: (Math.random() - 0.5) * 0.002,
        phase: Math.random() * Math.PI * 2,
        twinkleSpeed: 0.5 + Math.random() * 2,
      })
    }

    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3))
    starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3))
    starGeo.setAttribute('size', new THREE.BufferAttribute(starSizes, 1))

    const starMat = new THREE.PointsMaterial({
      size: 2, vertexColors: true, transparent: true, opacity: 0.55,
      sizeAttenuation: true, map: glowTexture, blending: THREE.AdditiveBlending, depthWrite: false,
    })
    const stars = new THREE.Points(starGeo, starMat)
    scene.add(stars)

    // Larger nebula dust
    const dustCount = 80
    const dustGeo = new THREE.BufferGeometry()
    const dustPos = new Float32Array(dustCount * 3)
    const dustColors = new Float32Array(dustCount * 3)
    const dustSizes = new Float32Array(dustCount)

    for (let i = 0; i < dustCount; i++) {
      dustPos[i * 3] = (Math.random() - 0.5) * 90
      dustPos[i * 3 + 1] = (Math.random() - 0.5) * 55
      dustPos[i * 3 + 2] = (Math.random() - 0.5) * 25

      const isPurple = Math.random() > 0.5
      dustColors[i * 3] = isPurple ? 0.6 : 0.1
      dustColors[i * 3 + 1] = isPurple ? 0.3 : 0.5
      dustColors[i * 3 + 2] = isPurple ? 0.9 : 0.7

      dustSizes[i] = 10 + Math.random() * 18
    }

    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3))
    dustGeo.setAttribute('color', new THREE.BufferAttribute(dustColors, 3))
    dustGeo.setAttribute('size', new THREE.BufferAttribute(dustSizes, 1))

    const dustMat = new THREE.PointsMaterial({
      size: 15, vertexColors: true, transparent: true, opacity: 0.08,
      sizeAttenuation: true, map: glowTexture, blending: THREE.AdditiveBlending, depthWrite: false,
    })
    const dust = new THREE.Points(dustGeo, dustMat)
    scene.add(dust)

    // Very subtle connection lines between nearby stars
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x8888aa, transparent: true, opacity: 0.02,
      blending: THREE.AdditiveBlending, depthWrite: false,
    })
    let linesMesh: THREE.LineSegments | null = null

    function updateConnections() {
      if (linesMesh) { scene.remove(linesMesh); linesMesh.geometry.dispose() }
      const linePositions: number[] = []
      const posArray = starGeo.attributes.position.array as Float32Array
      for (let i = 0; i < starCount; i++) {
        let connections = 0
        for (let j = i + 1; j < starCount; j++) {
          if (connections >= 1) break
          const dx = posArray[i * 3] - posArray[j * 3]
          const dy = posArray[i * 3 + 1] - posArray[j * 3 + 1]
          const dz = posArray[i * 3 + 2] - posArray[j * 3 + 2]
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz)
          if (dist < 15) {
            linePositions.push(posArray[i * 3], posArray[i * 3 + 1], posArray[i * 3 + 2], posArray[j * 3], posArray[j * 3 + 1], posArray[j * 3 + 2])
            connections++
          }
        }
      }
      if (linePositions.length > 0) {
        const lineGeometry = new THREE.BufferGeometry()
        lineGeometry.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3))
        linesMesh = new THREE.LineSegments(lineGeometry, lineMat)
        scene.add(linesMesh)
      }
    }

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1
    }
    window.addEventListener('mousemove', handleMouseMove, { passive: true })

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', handleResize, { passive: true })

    let animationId: number
    let time = 0
    let frameCount = 0

    const animate = () => {
      animationId = requestAnimationFrame(animate)
      time += 0.005
      frameCount++
      if (frameCount % 4 === 0) updateConnections()

      const sArr = starGeo.attributes.position.array as Float32Array
      const sSizeArr = starGeo.attributes.size.array as Float32Array
      const mouseWorldX = mouseRef.current.x * 35
      const mouseWorldY = mouseRef.current.y * 22

      for (let i = 0; i < starCount; i++) {
        // Slow constellation drift
        sArr[i * 3] += starData[i].driftX + Math.sin(time * 0.3 + starData[i].phase) * 0.001
        sArr[i * 3 + 1] += starData[i].driftY + Math.cos(time * 0.2 + starData[i].phase) * 0.001
        sArr[i * 3 + 2] += starData[i].driftZ

        // Wrap
        if (sArr[i * 3] > 55) sArr[i * 3] = -55
        if (sArr[i * 3] < -55) sArr[i * 3] = 55
        if (sArr[i * 3 + 1] > 35) sArr[i * 3 + 1] = -35
        if (sArr[i * 3 + 1] < -35) sArr[i * 3 + 1] = 35

        // Cursor creates a gentle wake
        const dx = sArr[i * 3] - mouseWorldX
        const dy = sArr[i * 3 + 1] - mouseWorldY
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist < 20 && dist > 0.1) {
          const force = (20 - dist) / 20 * 0.012
          sArr[i * 3] += (dx / dist) * force
          sArr[i * 3 + 1] += (dy / dist) * force
        }

        // Twinkle size
        const twinkle = Math.sin(time * starData[i].twinkleSpeed + starData[i].phase) * 0.3 + 0.7
        sSizeArr[i] = (1.2 + starData[i].phase % 2.5) * twinkle
      }
      starGeo.attributes.position.needsUpdate = true
      starGeo.attributes.size.needsUpdate = true

      // Dust slow rotation
      const dArr = dustGeo.attributes.position.array as Float32Array
      for (let i = 0; i < dustCount; i++) {
        dArr[i * 3] += Math.sin(time * 0.1 + i) * 0.003
        dArr[i * 3 + 1] += Math.cos(time * 0.08 + i * 0.5) * 0.002
      }
      dustGeo.attributes.position.needsUpdate = true

      // Camera gentle parallax
      camera.position.x += (mouseRef.current.x * 3 - camera.position.x) * 0.015
      camera.position.y += (mouseRef.current.y * 2 - camera.position.y) * 0.015
      camera.lookAt(0, 0, 0)

      renderer.render(scene, camera)
    }
    animate()

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('resize', handleResize)
      starGeo.dispose(); starMat.dispose(); dustGeo.dispose(); dustMat.dispose(); lineMat.dispose(); glowTexture.dispose()
      if (linesMesh) linesMesh.geometry.dispose()
      renderer.dispose()
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement)
    }
  }, [])

  return <div ref={containerRef} style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, pointerEvents: 'none' }} />
}
