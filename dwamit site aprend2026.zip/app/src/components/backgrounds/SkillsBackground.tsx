import { useEffect, useRef } from 'react'
import * as THREE from 'three'

export default function SkillsBackground() {
  const containerRef = useRef<HTMLDivElement>(null)
  const mouseRef = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.z = 55
    camera.position.y = 5

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    container.appendChild(renderer.domElement)

    // Create 3D grid of small glowing cubes
    const gridSizeX = 20
    const gridSizeY = 12
    const spacing = 4
    const cubes: { mesh: THREE.Mesh; baseColor: THREE.Color; pulsePhase: number; pulseSpeed: number }[] = []

    for (let x = 0; x < gridSizeX; x++) {
      for (let y = 0; y < gridSizeY; y++) {
        const size = 0.3 + Math.random() * 0.4
        const geometry = new THREE.BoxGeometry(size, size, size)
        const hue = Math.random() > 0.6 ? 0.52 : 0.15 // cyan or gold
        const color = new THREE.Color().setHSL(hue, 0.7, 0.5)
        const material = new THREE.MeshBasicMaterial({
          color,
          transparent: true,
          opacity: 0.15,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })

        const mesh = new THREE.Mesh(geometry, material)
        mesh.position.set(
          (x - gridSizeX / 2) * spacing,
          (y - gridSizeY / 2) * spacing,
          (Math.random() - 0.5) * 15
        )
        scene.add(mesh)

        cubes.push({
          mesh,
          baseColor: color.clone(),
          pulsePhase: Math.random() * Math.PI * 2,
          pulseSpeed: 0.5 + Math.random() * 1.5,
        })
      }
    }

    // Horizontal grid lines
    const lineMaterial = new THREE.LineBasicMaterial({
      color: 0x22d3ee,
      transparent: true,
      opacity: 0.03,
      blending: THREE.AdditiveBlending,
    })

    for (let y = 0; y < gridSizeY; y++) {
      const points = []
      for (let x = 0; x < gridSizeX; x++) {
        points.push(new THREE.Vector3((x - gridSizeX / 2) * spacing, (y - gridSizeY / 2) * spacing, 0))
      }
      const geo = new THREE.BufferGeometry().setFromPoints(points)
      const line = new THREE.Line(geo, lineMaterial)
      scene.add(line)
    }

    for (let x = 0; x < gridSizeX; x++) {
      const points = []
      for (let y = 0; y < gridSizeY; y++) {
        points.push(new THREE.Vector3((x - gridSizeX / 2) * spacing, (y - gridSizeY / 2) * spacing, 0))
      }
      const geo = new THREE.BufferGeometry().setFromPoints(points)
      const line = new THREE.Line(geo, lineMaterial)
      scene.add(line)
    }

    // Data stream particles
    const streamGeo = new THREE.BufferGeometry()
    const streamCount = 200
    const streamPos = new Float32Array(streamCount * 3)
    const streamSpeeds: number[] = []
    for (let i = 0; i < streamCount; i++) {
      streamPos[i * 3] = (Math.random() - 0.5) * 100
      streamPos[i * 3 + 1] = (Math.random() - 0.5) * 60
      streamPos[i * 3 + 2] = (Math.random() - 0.5) * 20
      streamSpeeds.push(0.02 + Math.random() * 0.05)
    }
    streamGeo.setAttribute('position', new THREE.BufferAttribute(streamPos, 3))
    const streamMat = new THREE.PointsMaterial({
      size: 1.2,
      color: 0x22d3ee,
      transparent: true,
      opacity: 0.4,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
    const streamPoints = new THREE.Points(streamGeo, streamMat)
    scene.add(streamPoints)

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1
    }
    window.addEventListener('mousemove', handleMouseMove, { passive: true })

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', handleResize, { passive: true })

    let animationId: number
    let time = 0

    const animate = () => {
      animationId = requestAnimationFrame(animate)
      time += 0.01

      const mouseWorldX = mouseRef.current.x * 45
      const mouseWorldY = mouseRef.current.y * 30

      cubes.forEach((cube) => {
        // Pulse opacity
        const pulse = Math.sin(time * cube.pulseSpeed + cube.pulsePhase) * 0.5 + 0.5
        ;(cube.mesh.material as THREE.MeshBasicMaterial).opacity = 0.08 + pulse * 0.15

        // Mouse proximity glow
        const dx = cube.mesh.position.x - mouseWorldX
        const dy = cube.mesh.position.y - mouseWorldY
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist < 12) {
          const glow = (12 - dist) / 12
          ;(cube.mesh.material as THREE.MeshBasicMaterial).opacity = 0.3 + glow * 0.4
          cube.mesh.scale.setScalar(1 + glow * 0.5)
        } else {
          cube.mesh.scale.setScalar(1)
        }

        // Gentle rotation
        cube.mesh.rotation.x += 0.005
        cube.mesh.rotation.y += 0.007
      })

      // Animate data streams
      const sPos = streamGeo.attributes.position.array as Float32Array
      for (let i = 0; i < streamCount; i++) {
        sPos[i * 3] += streamSpeeds[i]
        if (sPos[i * 3] > 50) sPos[i * 3] = -50
      }
      streamGeo.attributes.position.needsUpdate = true

      // Camera follows mouse slightly
      camera.position.x += (mouseRef.current.x * 5 - camera.position.x) * 0.02
      camera.position.y += (5 + mouseRef.current.y * 3 - camera.position.y) * 0.02
      camera.lookAt(0, 0, 0)

      renderer.render(scene, camera)
    }
    animate()

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('resize', handleResize)
      cubes.forEach(c => { c.mesh.geometry.dispose(); (c.mesh.material as THREE.Material).dispose() })
      streamGeo.dispose(); streamMat.dispose()
      renderer.dispose()
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement)
    }
  }, [])

  return <div ref={containerRef} style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, pointerEvents: 'none' }} />
}
