import { useEffect, useRef } from 'react'
import * as THREE from 'three'

function createGlowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas')
  canvas.width = 64
  canvas.height = 64
  const ctx = canvas.getContext('2d')!
  const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
  gradient.addColorStop(0, 'rgba(255, 255, 255, 1)')
  gradient.addColorStop(0.3, 'rgba(255, 255, 255, 0.6)')
  gradient.addColorStop(0.6, 'rgba(255, 255, 255, 0.15)')
  gradient.addColorStop(1, 'rgba(255, 255, 255, 0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, 64, 64)
  return new THREE.CanvasTexture(canvas)
}

export default function ContactBackground() {
  const containerRef = useRef<HTMLDivElement>(null)
  const mouseRef = useRef({ x: 0, y: 0, active: false })

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const scene = new THREE.Scene()
    scene.fog = new THREE.FogExp2(0x0f0a0a, 0.01)

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.z = 50
    camera.position.y = -10

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    container.appendChild(renderer.domElement)

    const glowTexture = createGlowTexture()
    const particleCount = 600

    const geometry = new THREE.BufferGeometry()
    const positions = new Float32Array(particleCount * 3)
    const colors = new Float32Array(particleCount * 3)
    const sizes = new Float32Array(particleCount)
    const particlesData: { speed: number; wobble: number; phase: number }[] = []

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 80
      positions[i * 3 + 1] = -30 - Math.random() * 40
      positions[i * 3 + 2] = (Math.random() - 0.5) * 30

      // Warm colors: orange, amber, gold, soft red
      const colorChoice = Math.random()
      let r: number, g: number, b: number
      if (colorChoice < 0.35) {
        r = 0.98; g = 0.45 + Math.random() * 0.2; b = 0.09
      } else if (colorChoice < 0.65) {
        r = 0.83; g = 0.66 + Math.random() * 0.1; b = 0.26
      } else if (colorChoice < 0.85) {
        r = 1.0; g = 0.6 + Math.random() * 0.2; b = 0.0
      } else {
        r = 0.9; g = 0.3; b = 0.1
      }
      colors[i * 3] = r
      colors[i * 3 + 1] = g
      colors[i * 3 + 2] = b

      sizes[i] = 2.5 + Math.random() * 2
      particlesData.push({
        speed: 0.02 + Math.random() * 0.04,
        wobble: Math.random() * 0.02,
        phase: Math.random() * Math.PI * 2,
      })
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1))

    const material = new THREE.PointsMaterial({
      size: 2.5,
      vertexColors: true,
      transparent: true,
      opacity: 0.6,
      sizeAttenuation: true,
      map: glowTexture,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })

    const points = new THREE.Points(geometry, material)
    scene.add(points)

    // Floating warm light orbs
    const orbGeo = new THREE.SphereGeometry(1, 16, 16)
    const orbs: { mesh: THREE.Mesh; speed: number; phase: number }[] = []
    for (let i = 0; i < 8; i++) {
      const orbMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color().setHSL(0.08 + Math.random() * 0.06, 0.8, 0.5),
        transparent: true,
        opacity: 0.06,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
      const mesh = new THREE.Mesh(orbGeo, orbMat)
      mesh.position.set((Math.random() - 0.5) * 60, (Math.random() - 0.5) * 40, (Math.random() - 0.5) * 20)
      mesh.scale.setScalar(2 + Math.random() * 4)
      scene.add(mesh)
      orbs.push({ mesh, speed: 0.005 + Math.random() * 0.01, phase: Math.random() * Math.PI * 2 })
    }

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1
      mouseRef.current.active = true
    }
    const handleMouseLeave = () => { mouseRef.current.active = false }
    window.addEventListener('mousemove', handleMouseMove, { passive: true })
    window.addEventListener('mouseleave', handleMouseLeave, { passive: true })

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', handleResize, { passive: true })

    let animationId: number
    let time = 0

    const animate = () => {
      animationId = requestAnimationFrame(animate)
      time += 0.01

      const posArray = geometry.attributes.position.array as Float32Array
      const sizeArray = geometry.attributes.size.array as Float32Array
      const mouseWorldX = mouseRef.current.x * 40

      for (let i = 0; i < particleCount; i++) {
        // Rise upward like embers
        posArray[i * 3 + 1] += particlesData[i].speed
        // Gentle horizontal wobble
        posArray[i * 3] += Math.sin(time + particlesData[i].phase) * particlesData[i].wobble
        posArray[i * 3 + 2] += Math.cos(time * 0.7 + particlesData[i].phase) * particlesData[i].wobble * 0.5

        // Mouse creates wind
        if (mouseRef.current.active) {
          const dx = posArray[i * 3] - mouseWorldX
          posArray[i * 3] -= dx * 0.002
          // Particles near mouse grow and brighten
          const dist = Math.abs(dx)
          if (dist < 15) {
            const warmth = (15 - dist) / 15
            sizeArray[i] = (2.5 + particlesData[i].phase % 2) * (1 + warmth)
          } else {
            sizeArray[i] = 2.5 + particlesData[i].phase % 2
          }
        } else {
          sizeArray[i] = 2.5 + particlesData[i].phase % 2
        }

        // Reset when too high
        if (posArray[i * 3 + 1] > 40) {
          posArray[i * 3 + 1] = -30 - Math.random() * 10
          posArray[i * 3] = (Math.random() - 0.5) * 80
        }
      }
      geometry.attributes.position.needsUpdate = true
      geometry.attributes.size.needsUpdate = true

      // Animate orbs
      orbs.forEach((orb) => {
        orb.mesh.position.y += Math.sin(time * orb.speed + orb.phase) * 0.02
        orb.mesh.position.x += Math.cos(time * orb.speed * 0.5 + orb.phase) * 0.01
        const scalePulse = 1 + Math.sin(time * 0.5 + orb.phase) * 0.1
        orb.mesh.scale.setScalar((2 + orb.phase % 4) * scalePulse)
      })

      // Camera gentle sway
      camera.position.x = Math.sin(time * 0.1) * 2
      camera.lookAt(0, 5, 0)

      renderer.render(scene, camera)
    }
    animate()

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseleave', handleMouseLeave)
      window.removeEventListener('resize', handleResize)
      geometry.dispose(); material.dispose(); glowTexture.dispose()
      orbs.forEach(o => { o.mesh.geometry.dispose(); (o.mesh.material as THREE.Material).dispose() })
      renderer.dispose()
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement)
    }
  }, [])

  return <div ref={containerRef} style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, pointerEvents: 'none' }} />
}
