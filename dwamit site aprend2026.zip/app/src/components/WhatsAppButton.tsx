import { useState } from 'react'
import { motion } from 'framer-motion'
import { MessageCircle } from 'lucide-react'

export default function WhatsAppButton() {
  const [hovered, setHovered] = useState(false)

  return (
    <motion.a
      href="https://wa.me/971503855067?text=Hello"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed z-50 flex items-center gap-3"
      style={{ bottom: 32, right: 32 }}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      whileHover={{ scale: 1.15 }}
      whileTap={{ scale: 0.95 }}
    >
      {/* Label */}
      <motion.span
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: hovered ? 1 : 0, x: hovered ? 0 : 20 }}
        transition={{ duration: 0.3 }}
        className="text-sm font-medium whitespace-nowrap px-3 py-1 rounded-full"
        style={{
          background: 'rgba(37, 211, 102, 0.2)',
          color: '#25D366',
          border: '1px solid rgba(37, 211, 102, 0.3)',
        }}
      >
        Say Hello
      </motion.span>

      {/* Button */}
      <div
        className="rounded-full flex items-center justify-center whatsapp-pulse"
        style={{
          width: 60,
          height: 60,
          background: '#25D366',
          boxShadow: hovered
            ? '0 0 30px rgba(37, 211, 102, 0.4)'
            : '0 4px 15px rgba(37, 211, 102, 0.3)',
        }}
      >
        <MessageCircle size={28} color="white" fill="white" />
      </div>
    </motion.a>
  )
}
