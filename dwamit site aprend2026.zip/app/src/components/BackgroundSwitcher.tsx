import { useBackground } from './BackgroundContext'
import HomeBackground from './backgrounds/HomeBackground'
import AboutBackground from './backgrounds/AboutBackground'
import ExperienceBackground from './backgrounds/ExperienceBackground'
import SkillsBackground from './backgrounds/SkillsBackground'
import ContactBackground from './backgrounds/ContactBackground'

export default function BackgroundSwitcher() {
  const { route } = useBackground()

  switch (route) {
    case 'home':
      return <HomeBackground />
    case 'about':
      return <AboutBackground />
    case 'experience':
      return <ExperienceBackground />
    case 'skills':
      return <SkillsBackground />
    case 'contact':
      return <ContactBackground />
    default:
      return <HomeBackground />
  }
}
