import { createContext, useContext, useState, useCallback } from 'react'

interface BackgroundContextType {
  route: string
  setRoute: (route: string) => void
}

const BackgroundContext = createContext<BackgroundContextType>({
  route: 'home',
  setRoute: () => {},
})

export function BackgroundProvider({ children }: { children: React.ReactNode }) {
  const [route, setRouteState] = useState<string>('home')

  const setRoute = useCallback((newRoute: string) => {
    const cleanRoute = newRoute === '/' ? 'home' : newRoute.replace(/^\//, '')
    setRouteState(cleanRoute)
  }, [])

  return (
    <BackgroundContext.Provider value={{ route, setRoute }}>
      {children}
    </BackgroundContext.Provider>
  )
}

export function useBackground() {
  return useContext(BackgroundContext)
}
