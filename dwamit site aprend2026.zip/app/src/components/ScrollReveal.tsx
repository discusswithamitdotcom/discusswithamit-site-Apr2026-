import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

interface ScrollRevealProps {
  children: React.ReactNode
  className?: string
  direction?: 'up' | 'down' | 'left' | 'right' | 'scale'
  delay?: number
  duration?: number
  distance?: number
  stagger?: number
}

export default function ScrollReveal({
  children,
  className = '',
  direction = 'up',
  delay = 0,
  duration = 1,
  distance = 60,
  stagger = 0.1,
}: ScrollRevealProps) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const childrenEls = el.children.length > 0 ? Array.from(el.children) : [el]

    const fromVars: gsap.TweenVars = { opacity: 0 }
    if (direction === 'up') fromVars.y = distance
    else if (direction === 'down') fromVars.y = -distance
    else if (direction === 'left') fromVars.x = -distance
    else if (direction === 'right') fromVars.x = distance
    else if (direction === 'scale') fromVars.scale = 0.9

    const tween = gsap.from(childrenEls, {
      ...fromVars,
      duration,
      delay,
      stagger,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: el,
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    })

    return () => {
      tween.kill()
      ScrollTrigger.getAll().forEach((st) => {
        if (st.trigger === el) st.kill()
      })
    }
  }, [direction, delay, duration, distance, stagger])

  return (
    <div ref={ref} className={className}>
      {children}
    </div>
  )
}
