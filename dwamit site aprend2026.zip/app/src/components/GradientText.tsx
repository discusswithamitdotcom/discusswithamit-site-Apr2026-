import type { ReactNode } from 'react'

interface GradientTextProps {
  children: ReactNode
  className?: string
  variant?: 'gold' | 'full'
}

export default function GradientText({ children, className = '', variant = 'full' }: GradientTextProps) {
  return (
    <span
      className={className}
      style={{
        background: variant === 'gold'
          ? 'linear-gradient(135deg, #d4a843, #f0c76b)'
          : 'linear-gradient(135deg, #d4a843, #f5f0e8, #00e5ff)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
        backgroundClip: 'text',
      }}
    >
      {children}
    </span>
  )
}
