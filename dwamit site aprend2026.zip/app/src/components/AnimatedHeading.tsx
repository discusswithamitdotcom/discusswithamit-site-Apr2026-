import { useEffect, useRef, useState } from 'react'

interface AnimatedHeadingProps {
  text: string
  className?: string
  as?: 'h1' | 'h2' | 'h3'
  delay?: number
}

export default function AnimatedHeading({ text, className = '', as: Tag = 'h1', delay = 0 }: AnimatedHeadingProps) {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLHeadingElement>(null)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), delay * 1000)
    return () => clearTimeout(timer)
  }, [delay])

  const chars = text.split('')

  return (
    <Tag ref={ref} className={className}>
      {chars.map((char, i) => (
        <span
          key={i}
          className="char"
          style={{
            animationDelay: `${delay + i * 0.03}s`,
            animationPlayState: isVisible ? 'running' : 'paused',
            whiteSpace: char === ' ' ? 'pre' : undefined,
          }}
        >
          {char === ' ' ? '\u00A0' : char}
        </span>
      ))}
    </Tag>
  )
}
