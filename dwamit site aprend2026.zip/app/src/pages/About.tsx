import { motion } from 'framer-motion'
import { Trophy, ListChecks, Search, Heart, Globe, Zap, FileText, Music, ChefHat } from 'lucide-react'
import GlassCard from '../components/GlassCard'
import ScrollReveal from '../components/ScrollReveal'

const knowMeItems = [
  { icon: Trophy, text: 'FinTech is sports to me' },
  { icon: ListChecks, text: "Being Systematic: Everything's tracked. Nothing forgotten." },
  { icon: Search, text: 'Obsessed with Research & Root Cause Investigations' },
  { icon: Heart, text: 'Engaging with me gets people to love their work while they live at work' },
]

const fintechProducts = [
  'Financial Inclusion', 'Digital Payments', 'e-Governance', 'Automations on A/R A/P EIPP',
  'ATMs & MicroATMs', 'Payment Cards', 'Merchant Acquiring', 'POS', 'Biometric',
  'RegTech', 'Forex', 'Neobank', 'Open Banking', 'Payment rails of the world',
  'Last Mile', 'Remittances', 'Kiosk Banking', 'Banking Correspondent', 'Branchless Banking',
  'API', 'SaaS', 'White Label', 'Custom Software', 'APK SDK', 'AI ML',
]

const cryptoProducts = [
  'DeFi', 'CeFi', 'DEX', 'Exchange', 'Crypto Exchanges', 'Payment Gateway',
  'Merchant Solutions', 'Stablecoin banking', 'Compliance Technologies', 'KYC', 'KYB', 'KYT',
  'On-ramps off-ramps', 'Non-custodial wallet',
]

const hobbies = [
  { icon: Globe, label: 'Geopolitics', gradient: 'from-amber-500/20 to-cyan-500/20' },
  { icon: Zap, label: 'Martial Arts & Fitness', gradient: 'from-orange-500/20 to-red-500/20' },
  { icon: FileText, label: 'Industry Publications', gradient: 'from-cyan-500/20 to-blue-500/20' },
  { icon: Music, label: 'Bass Guitarist', gradient: 'from-purple-500/20 to-pink-500/20' },
  { icon: ChefHat, label: 'Cooking', gradient: 'from-green-500/20 to-emerald-500/20' },
]

export default function About() {
  return (
    <div>
      {/* Hero Intro */}
      <section className="min-h-[80vh] flex items-center relative" style={{ paddingTop: 120 }}>
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at 20% 50%, rgba(10,10,18,0.85) 0%, transparent 70%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 w-full relative z-10">
          <div className="max-w-3xl">
              <h1
                className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight leading-tight mb-8"
                style={{ wordBreak: 'keep-all', overflowWrap: 'normal', hyphens: 'none' }}
              >
                The Swiss Army Knife of FinTech
              </h1>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5, duration: 0.8 }}
              className="space-y-4 text-base sm:text-lg"
              style={{
                color: 'rgba(245, 240, 232, 0.88)',
                textShadow: '0 2px 8px rgba(0,0,0,0.7)',
              }}
            >
              <p>
                A Swiss Army Knife in FinTech and Crypto, 9+ years — product, ops, tech and alliances.
                An operator, a man of principles, and manners of a diplomat. Ex-professor of fintech.
                Occasionally a public speaker and panelist.
              </p>
              <p>
                Taking care of both technical and business responsibilities, I guide and support
                Software Development, API integrations, Marketing, Design, Finance, GTM, Customer
                Support, Business Partnerships, Legal and Compliance. Builder, Scaler, Fixer.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Getting To Know Me */}
      <section className="py-20 md:py-28 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(10,10,18,0.65) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <ScrollReveal>
            <div className="flex items-center gap-4 mb-12">
              <span className="text-2xl font-bold" style={{ color: '#00e5ff', textShadow: '0 0 20px rgba(0,229,255,0.3)' }}>[</span>
              <h2 className="text-3xl md:text-4xl font-bold" style={{ textShadow: '0 2px 8px rgba(0,0,0,0.7)' }}>
                Getting to know me
              </h2>
              <span className="text-2xl font-bold" style={{ color: '#00e5ff', textShadow: '0 0 20px rgba(0,229,255,0.3)' }}>]</span>
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {knowMeItems.map((item, i) => (
              <ScrollReveal key={i} delay={i * 0.1} direction="scale">
                <GlassCard accent="cyan" intensity={8} className="p-8 h-full">
                  <item.icon
                    size={36}
                    className="mb-4"
                    style={{
                      color: '#00e5ff',
                      filter: 'drop-shadow(0 0 10px rgba(0,229,255,0.4))',
                    }}
                  />
                  <p className="text-base leading-relaxed" style={{ color: 'rgba(245,240,232,0.9)' }}>{item.text}</p>
                </GlassCard>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* FinTech Products */}
      <section className="py-20 md:py-28 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(12,10,4,0.65) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <ScrollReveal>
            <h2
              className="text-3xl md:text-4xl font-bold mb-10"
              style={{
                background: 'linear-gradient(135deg, #d4a843, #f0c76b)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                textShadow: 'none',
              }}
            >
              FinTech Products I've Managed
            </h2>
          </ScrollReveal>

          <ScrollReveal>
            <div className="flex flex-wrap gap-3">
              {fintechProducts.map((product, i) => (
                <motion.span
                  key={i}
                  className="inline-block px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 cursor-default"
                  style={{
                    background: 'rgba(212, 168, 67, 0.12)',
                    border: '1px solid rgba(212, 168, 67, 0.3)',
                    color: '#e8c86e',
                    textShadow: '0 1px 3px rgba(0,0,0,0.5)',
                  }}
                  whileHover={{ scale: 1.05, background: 'rgba(212, 168, 67, 0.25)' }}
                >
                  {product}
                </motion.span>
              ))}
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Crypto Products */}
      <section className="py-20 md:py-28 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(4,10,12,0.65) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <ScrollReveal>
            <h2 className="text-3xl md:text-4xl font-bold mb-10" style={{ color: '#00e5ff', textShadow: '0 0 30px rgba(0,229,255,0.2)' }}>
              Crypto Products I've Managed
            </h2>
          </ScrollReveal>

          <ScrollReveal>
            <div className="flex flex-wrap gap-3">
              {cryptoProducts.map((product, i) => (
                <motion.span
                  key={i}
                  className="inline-block px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 cursor-default"
                  style={{
                    background: 'rgba(0, 229, 255, 0.1)',
                    border: '1px solid rgba(0, 229, 255, 0.3)',
                    color: '#5ee8ff',
                    textShadow: '0 1px 3px rgba(0,0,0,0.5)',
                  }}
                  whileHover={{ scale: 1.05, background: 'rgba(0, 229, 255, 0.2)' }}
                >
                  {product}
                </motion.span>
              ))}
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Hobbies */}
      <section className="py-20 md:py-28 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(10,10,18,0.65) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <ScrollReveal>
            <h2
              className="text-3xl md:text-4xl font-bold mb-10"
              style={{
                background: 'linear-gradient(135deg, #d4a843, #f5f0e8, #00e5ff)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                textShadow: 'none',
              }}
            >
              Beyond the Code
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {hobbies.map((hobby, i) => (
              <ScrollReveal key={i} delay={i * 0.1} direction="scale">
                <GlassCard className="p-6 text-center h-full">
                  <div
                    className={`w-14 h-14 mx-auto mb-4 rounded-xl flex items-center justify-center bg-gradient-to-br ${hobby.gradient}`}
                  >
                    <hobby.icon size={24} style={{ color: '#f5f0e8', filter: 'drop-shadow(0 1px 3px rgba(0,0,0,0.5))' }} />
                  </div>
                  <p className="text-sm font-medium" style={{ color: 'rgba(245,240,232,0.9)' }}>{hobby.label}</p>
                </GlassCard>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
