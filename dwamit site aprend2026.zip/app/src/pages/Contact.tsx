import { motion } from 'framer-motion'
import { MessageCircle, Linkedin, Mail } from 'lucide-react'
import AnimatedHeading from '../components/AnimatedHeading'
import GlassCard from '../components/GlassCard'
import ScrollReveal from '../components/ScrollReveal'

const contactOptions = [
  {
    icon: MessageCircle,
    title: 'WhatsApp',
    detail: '+971 50 385 5067',
    cta: 'Message Me',
    href: 'https://wa.me/971503855067?text=Hello',
    accent: '#25D366',
  },
  {
    icon: Linkedin,
    title: 'LinkedIn',
    detail: 'linkedin.com/in/amit-sharma-international-fintech',
    cta: 'View Profile',
    href: 'https://www.linkedin.com/in/amit-sharma-international-fintech/',
    accent: '#0077B5',
  },
  {
    icon: Mail,
    title: 'Email',
    detail: 'Available upon request',
    cta: 'Request via WhatsApp',
    href: 'https://wa.me/971503855067?text=Hello',
    accent: '#d4a843',
  },
]

export default function Contact() {
  return (
    <div>
      {/* Hero */}
      <section className="min-h-[60vh] flex items-center justify-center relative" style={{ paddingTop: 120 }}>
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(14,8,6,0.8) 0%, transparent 70%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 text-center relative z-10">
          <AnimatedHeading
            text="Let's Connect"
            as="h1"
            className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight mb-6"
            delay={0.3}
          />
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="text-lg max-w-xl mx-auto"
            style={{
              color: 'rgba(245, 240, 232, 0.75)',
              textShadow: '0 2px 8px rgba(0,0,0,0.7)',
            }}
          >
            Open to advisory roles, consulting, leadership positions, and fintech/crypto ventures
          </motion.p>
        </div>
      </section>

      {/* Contact Options */}
      <section className="pb-24 md:pb-32 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(14,8,6,0.6) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {contactOptions.map((option, i) => (
              <ScrollReveal key={i} delay={i * 0.15} direction="scale">
                <GlassCard
                  accent={option.accent === '#d4a843' ? 'gold' : 'cyan'}
                  intensity={8}
                  className="p-8 h-full text-center flex flex-col items-center"
                >
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                    style={{
                      background: `${option.accent}18`,
                      border: `1px solid ${option.accent}35`,
                      boxShadow: `0 0 20px ${option.accent}15`,
                    }}
                  >
                    <option.icon size={32} style={{ color: option.accent, filter: `drop-shadow(0 0 6px ${option.accent}40)` }} />
                  </div>
                  <h3 className="text-xl font-bold mb-2" style={{ color: '#f5f0e8', textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>{option.title}</h3>
                  <p className="text-sm mb-6" style={{ color: 'rgba(245, 240, 232, 0.6)', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
                    {option.detail}
                  </p>
                  <a
                    href={option.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-6 py-3 rounded-lg font-semibold text-sm transition-all duration-300 mt-auto hover:scale-105"
                    style={{
                      background: `${option.accent}15`,
                      color: option.accent,
                      border: `1px solid ${option.accent}40`,
                      textShadow: '0 1px 3px rgba(0,0,0,0.4)',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.background = `${option.accent}30`
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.background = `${option.accent}15`
                    }}
                  >
                    {option.cta}
                  </a>
                </GlassCard>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Closing */}
      <section className="py-24 md:py-32 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(14,8,6,0.7) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 text-center relative z-10">
          <ScrollReveal>
            <p
              className="text-2xl md:text-3xl font-light italic mb-4"
              style={{
                color: 'rgba(245, 240, 232, 0.85)',
                textShadow: '0 2px 10px rgba(0,0,0,0.7)',
              }}
            >
              "Building the future of finance, one product at a time."
            </p>
          </ScrollReveal>
          <ScrollReveal delay={0.3}>
            <p
              className="text-lg font-semibold"
              style={{
                background: 'linear-gradient(135deg, #d4a843, #f0c76b)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              — Amit Sharma
            </p>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
