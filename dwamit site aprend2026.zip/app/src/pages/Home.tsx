import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ChevronDown, CreditCard, Bitcoin, Landmark, Wallet, Shield, Code } from 'lucide-react'
import AnimatedHeading from '../components/AnimatedHeading'
import GlassCard from '../components/GlassCard'
import ScrollReveal from '../components/ScrollReveal'
import StatCounter from '../components/StatCounter'

const summaryPoints = [
  '9+ years in fintech and crypto — product, ops, tech & alliances',
  'Operator mindset across Software, API, Marketing, Finance, GTM, Legal',
  'Global background: Caribbean-born · 11 yrs Africa · 11 yrs India · UAE',
  'Mastering French, Mandarin, Russian & Arabic',
]

const products = [
  { icon: CreditCard, label: 'Digital Payments & Gateways' },
  { icon: Bitcoin, label: 'Crypto Exchange & DeFi' },
  { icon: Landmark, label: 'Neobank & Open Banking' },
  { icon: Wallet, label: 'Payment Cards & Acquiring' },
  { icon: Shield, label: 'KYC/KYT & RegTech' },
  { icon: Code, label: 'APIs, SaaS & White Label' },
]

export default function Home() {
  const [showScrollIndicator, setShowScrollIndicator] = useState(true)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) setShowScrollIndicator(false)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div>
      {/* Hero Section */}
      <section
        className="min-h-screen flex items-center relative"
        style={{ paddingTop: 72 }}
      >
        {/* Dark scrim behind hero text */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at 30% 50%, rgba(10,10,15,0.85) 0%, transparent 70%)',
          }}
        />

        <div className="max-w-[1200px] mx-auto px-6 py-20 w-full relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
            {/* Left: Text Content */}
            <div className="flex-1 max-w-xl">
              <AnimatedHeading
                text="Amit Sharma"
                as="h1"
                className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-none mb-4"
                delay={0.3}
              />

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2, duration: 0.8 }}
                className="text-lg sm:text-xl mb-8"
                style={{
                  color: 'rgba(245, 240, 232, 0.75)',
                  textShadow: '0 2px 8px rgba(0,0,0,0.8)',
                }}
              >
                Fintech & Crypto Leader · Product · Operations · Strategy
              </motion.p>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.5, duration: 0.6 }}
                className="space-y-3 mb-10"
              >
                {summaryPoints.map((point, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 1.5 + i * 0.15, duration: 0.5 }}
                    className="flex items-start gap-3"
                  >
                    <span
                      className="w-1.5 h-1.5 rounded-full mt-2.5 flex-shrink-0"
                      style={{ background: '#d4a843', boxShadow: '0 0 6px rgba(212,168,67,0.5)' }}
                    />
                    <span
                      className="text-sm sm:text-base"
                      style={{
                        color: 'rgba(245, 240, 232, 0.85)',
                        textShadow: '0 1px 4px rgba(0,0,0,0.7)',
                      }}
                    >
                      {point}
                    </span>
                  </motion.div>
                ))}
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 2.2, duration: 0.6 }}
                className="flex flex-wrap gap-4"
              >
                <Link
                  to="/experience"
                  className="inline-flex items-center px-8 py-4 rounded-lg font-semibold text-sm transition-all duration-300 hover:brightness-110 hover:scale-105"
                  style={{
                    background: '#d4a843',
                    color: '#0a0a0f',
                    boxShadow: '0 4px 20px rgba(212,168,67,0.3)',
                  }}
                >
                  View My Experience
                </Link>
                <Link
                  to="/about"
                  className="inline-flex items-center px-8 py-4 rounded-lg font-semibold text-sm transition-all duration-300 hover:bg-[rgba(212,168,67,0.15)]"
                  style={{
                    border: '1px solid rgba(212, 168, 67, 0.5)',
                    color: '#d4a843',
                    textShadow: '0 1px 4px rgba(0,0,0,0.5)',
                  }}
                >
                  About Me
                </Link>
              </motion.div>
            </div>

            {/* Right: Avatar */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 1, ease: [0.22, 1, 0.36, 1] }}
              className="flex-shrink-0 relative z-10"
            >
              <div className="relative">
                {/* Glow */}
                <div
                  className="absolute inset-0 rounded-full blur-3xl opacity-40"
                  style={{ background: '#d4a843' }}
                />
                {/* Rotating border */}
                <div
                  className="absolute -inset-1 rounded-full avatar-border-rotate"
                  style={{
                    background: 'conic-gradient(from 0deg, transparent, #d4a843, transparent, #00e5ff, transparent)',
                    padding: 2,
                  }}
                />
                {/* Image */}
                <div
                  className="relative w-64 h-64 sm:w-72 sm:h-72 lg:w-96 lg:h-96 rounded-full overflow-hidden"
                  style={{
                    border: '2px solid rgba(212, 168, 67, 0.4)',
                    boxShadow: '0 0 60px rgba(212, 168, 67, 0.25), 0 0 120px rgba(212,168,67,0.1)',
                  }}
                >
                  <img
                    src="/avatar.jpg"
                    alt="Amit Sharma"
                    className="w-full h-full object-cover"
                    loading="eager"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll Indicator */}
        {showScrollIndicator && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 3, duration: 0.5 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-10"
          >
            <span
              className="text-xs uppercase tracking-widest"
              style={{ color: 'rgba(245, 240, 232, 0.5)', textShadow: '0 1px 4px rgba(0,0,0,0.8)' }}
            >
              Scroll to explore
            </span>
            <ChevronDown size={20} className="bounce-chevron" style={{ color: 'rgba(245, 240, 232, 0.5)' }} />
          </motion.div>
        )}
      </section>

      {/* Stats Bar */}
      <section
        className="py-12 md:py-16 relative"
        style={{
          background: 'rgba(10, 10, 15, 0.7)',
          backdropFilter: 'blur(10px)',
          borderTop: '1px solid rgba(255, 255, 255, 0.06)',
          borderBottom: '1px solid rgba(255, 255, 255, 0.06)',
        }}
      >
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <StatCounter end={9} suffix="+" label="Years Experience" />
            <StatCounter end={25} suffix="+" label="Products Managed" />
            <StatCounter end={150} suffix="K+" label="Users Reached" />
            <StatCounter end={5} label="Languages" />
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 md:py-32 relative">
        {/* Section scrim */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(10,10,15,0.6) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <ScrollReveal>
            <div className="flex items-center gap-4 mb-12">
              <h2
                className="text-3xl md:text-4xl font-bold"
                style={{
                  background: 'linear-gradient(135deg, #d4a843, #f5f0e8, #00e5ff)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                  textShadow: 'none',
                }}
              >
                Products I've Shaped
              </h2>
              <div className="flex-1 h-px" style={{ background: 'linear-gradient(to right, rgba(212,168,67,0.3), transparent)' }} />
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, i) => (
              <ScrollReveal key={i} delay={i * 0.1}>
                <GlassCard accent="gold" intensity={8} className="p-8 h-full">
                  <product.icon
                    size={40}
                    className="mb-4"
                    style={{
                      color: '#d4a843',
                      filter: 'drop-shadow(0 0 8px rgba(212,168,67,0.4))',
                    }}
                  />
                  <h3 className="text-lg font-semibold">{product.label}</h3>
                </GlassCard>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-24 md:py-32 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(10,10,15,0.7) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 text-center relative z-10">
          <ScrollReveal>
            <h2
              className="text-3xl md:text-5xl font-bold mb-6"
              style={{
                background: 'linear-gradient(135deg, #d4a843, #f5f0e8, #00e5ff)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              Let's Build Something Extraordinary
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.2}>
            <p
              className="text-lg mb-10 max-w-2xl mx-auto"
              style={{
                color: 'rgba(245, 240, 232, 0.8)',
                textShadow: '0 2px 8px rgba(0,0,0,0.7)',
              }}
            >
              Open to advisory, leadership, and consulting opportunities in fintech & crypto
            </p>
          </ScrollReveal>
          <ScrollReveal delay={0.4}>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/contact"
                className="inline-flex items-center px-8 py-4 rounded-lg font-semibold text-sm transition-all duration-300 hover:brightness-110 hover:scale-105"
                style={{
                  background: '#d4a843',
                  color: '#0a0a0f',
                  boxShadow: '0 4px 20px rgba(212,168,67,0.3)',
                }}
              >
                Get in Touch
              </Link>
              <a
                href="https://www.linkedin.com/in/amit-sharma-international-fintech/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-8 py-4 rounded-lg font-semibold text-sm transition-all duration-300 hover:bg-[rgba(212,168,67,0.15)]"
                style={{
                  border: '1px solid rgba(212, 168, 67, 0.5)',
                  color: '#d4a843',
                  textShadow: '0 1px 4px rgba(0,0,0,0.5)',
                }}
              >
                LinkedIn
              </a>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
