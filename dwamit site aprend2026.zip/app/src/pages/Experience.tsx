import { motion } from 'framer-motion'
import { MapPin } from 'lucide-react'
import AnimatedHeading from '../components/AnimatedHeading'
import GlassCard from '../components/GlassCard'
import ScrollReveal from '../components/ScrollReveal'

interface JobEntry {
  company: string
  role: string
  period: string
  location: string
  side: 'left' | 'right'
  image: string
  content: React.ReactNode
  highlights?: { label: string; value: string }[]
  badges?: string[]
}

const jobs: JobEntry[] = [
  {
    company: 'Multiple Tech Companies',
    role: 'Advisor, Leadership & Consultant',
    period: "Aug '24 - Present",
    location: 'Dubai',
    side: 'left',
    image: '/experience/img1.jpg',
    content: (
      <div className="space-y-3 text-sm" style={{ color: 'rgba(245, 240, 232, 0.85)', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
        <ul className="space-y-2 list-disc list-inside">
          <li><strong style={{ color: '#f5f0e8' }}>Navayuvak Entrepreneurs</strong> | VP Ops & Mentor — Setup of accelerator, incubator, management training programs and investments</li>
          <li><strong style={{ color: '#f5f0e8' }}>Crypto-Banking</strong> | VP Product</li>
          <li><strong style={{ color: '#f5f0e8' }}>Toogle</strong> | Tech & Product Partner, SaaS on traveltech, payment gateway, networking & more</li>
          <li><strong style={{ color: '#f5f0e8' }}>Reguard.ai</strong> | Consultant, RegTech</li>
          <li><strong style={{ color: '#f5f0e8' }}>HebronChain</strong> | CPTO for RWA, Agriculture</li>
          <li><strong style={{ color: '#f5f0e8' }}>INIA Global</strong> | Managing Consultant, CRM development</li>
          <li><strong style={{ color: '#f5f0e8' }}>RG Media</strong> | Head of Strategy & Product</li>
        </ul>
        <p>Products: Crypto news (coinheadlines, timescrypto, altcoindesk, coinmedium), Smart Contract Audit, Private KYC, ICO Listing, DEX Screener, On-chain investigation tools.</p>
      </div>
    ),
    highlights: [
      { label: 'Monthly Page Views', value: '37,500+' },
      { label: 'Reach', value: '100,000+' },
      { label: 'Followers', value: '5,500+' },
    ],
  },
  {
    company: 'VAI Management - Fintech & Crypto Exchange',
    role: 'Product Manager',
    period: "Jan '22 - July '24",
    location: 'Dubai',
    side: 'right',
    image: '/experience/img2.jpg',
    content: (
      <div className="space-y-3 text-sm" style={{ color: 'rgba(245, 240, 232, 0.85)', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
        <p>Reporting to Chairman, I was the single-point of guidance to all departments. Operator and decision maker on technical, ops, business, vendors, software development, product & project for 25+ crypto platforms — at the same time.</p>
        <div className="space-y-1">
          <p className="font-semibold" style={{ color: '#f5f0e8' }}>Products managed:</p>
          <ul className="space-y-1 list-disc list-inside">
            <li>Ecosystem of 25+ crypto apps — CeFi & DeFi. Transactions in billions USD, userbase 150,000+</li>
            <li>Crypto Exchanges (koinbay, layerK), Payment Cards, Crypto banking, Neobank, Travel booking, Payment Gateway, Digital Payments, onramps offramps, Gift cards</li>
            <li>Cross-chain DEX, staking, lending, Merchant solutions, Forex, Academy, Digital ID</li>
            <li>Non-custodial wallet, institutional custody, Proprietary blockchain, Bridge</li>
          </ul>
        </div>
        <p>Directed API integrations, feature developments, Departments SOPs, due diligence, UI/UX & QA. As a designated fintech subject matter expert, intervened to develop and manage other ecosystem products too.</p>
        <p>Panel Speaker at Gitex '22. Writer of Whitepapers, FAQs and roadmaps of all products.</p>
      </div>
    ),
    badges: ["Promoted from project to product", "Gitex '22 Panel Speaker"],
  },
  {
    company: 'BML Munjal University',
    role: 'Professor',
    period: "June '21 - Dec '21",
    location: 'Dubai, Mumbai',
    side: 'left',
    image: '/experience/img3.jpg',
    content: (
      <div className="space-y-3 text-sm" style={{ color: 'rgba(245, 240, 232, 0.85)', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
        <p>Visiting Faculty for Fintech and Banking Technology.</p>
        <p>I curated the curriculum and taught it.</p>
      </div>
    ),
  },
  {
    company: 'Global PayEX',
    role: 'Operations Manager',
    period: "Sept '20 - Dec '21",
    location: 'Mumbai',
    side: 'right',
    image: '/experience/img4.jpg',
    content: (
      <div className="space-y-3 text-sm" style={{ color: 'rgba(245, 240, 232, 0.85)', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
        <p>Products: Fintech for reconciliations and invoice tech. EIPP of Accounts Receivable & Accounts Payables for fortune companies — by integration with banks and ERPs with AI ML components.</p>
        <p>Reporting to COO, I took up ops, project, revenue, onboarding, revivals, stabilization, and SOP development for fortune clients.</p>
        <ul className="space-y-1 list-disc list-inside">
          <li>0 to 100,000+ users within 5 months. Fortune clients mandated our stack to their entire distribution chain through my growth methods.</li>
          <li>Recognised by founder to hit the ground running from day 1. Entrusted with accounts from day 3. Critical accounts of VP Ops by end of Month. Mentored new managers on my approach.</li>
          <li>Strategist and trainer on user growth and revenue — to both our teams (BA, support, sales) and client's (leadership, sales, finance)</li>
          <li>Acted as an intelligence & analytics wing of the clients to our departments and directors — for cross-sell, upsell and bespoke product policies for higher revenue</li>
        </ul>
      </div>
    ),
    highlights: [
      { label: 'Users in 5 Months', value: '0 to 100K+' },
      { label: 'Recognition', value: 'Day 1 Impact' },
    ],
  },
  {
    company: 'Mahagram Payments',
    role: 'Head of Projects',
    period: "Mar '17 - Aug '20",
    location: 'Mumbai',
    side: 'left',
    image: '/experience/img5.jpg',
    content: (
      <div className="space-y-3 text-sm" style={{ color: 'rgba(245, 240, 232, 0.85)', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
        <p>Products: Fintech for Financial Inclusion through API, white label, self-brand and custom software, including NPCI's products. Remittances (IMPS), Payments, Kiosk Banking, Digital ID (Aadhaar), e-governance (PAN), Bill Payments (BBPS), Merchant Acquiring, POS and Biometrics.</p>
        <p>Reporting to Founder, I took up product, project, strategic alliances, reforms, transformations, technical lead, GTM, B2B partnerships, vendor and government relations, and ops. Promoted from biz to project.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
          <div>
            <p className="font-semibold text-white text-xs uppercase tracking-wider mb-1">Product</p>
            <ul className="space-y-1 list-disc list-inside text-xs" style={{ color: 'rgba(245,240,232,0.8)' }}>
              <li>Developed custom software 0 to 1 with 550% upsell and only 9% to vendor</li>
              <li>Guided API integrations, took up CRM development & PCI DSS</li>
            </ul>
          </div>
          <div>
            <p className="font-semibold text-white text-xs uppercase tracking-wider mb-1">Ops</p>
            <ul className="space-y-1 list-disc list-inside text-xs" style={{ color: 'rgba(245,240,232,0.8)' }}>
              <li>Reduced TAT from 4.5 weeks to 1.5 weeks of digital ID applications</li>
              <li>30 days to 4 days for BBPS ID activations</li>
              <li>30+ days to 40 mins of immediate grievance resolutions</li>
            </ul>
          </div>
          <div className="sm:col-span-2">
            <p className="font-semibold text-white text-xs uppercase tracking-wider mb-1">Business</p>
            <ul className="space-y-1 list-disc list-inside text-xs" style={{ color: 'rgba(245,240,232,0.8)' }}>
              <li>Upsell 200%, Crossed 177% of targets — self generated leads, closed without founder director intervention</li>
              <li>257 outbound leads, Further 9,444 all by self-sourced methods</li>
            </ul>
          </div>
        </div>
      </div>
    ),
    highlights: [
      { label: 'Retail Points', value: '375,000+' },
      { label: 'Upsell', value: '550%' },
      { label: 'Target Achievement', value: '177%' },
      { label: 'Self-Sourced Leads', value: '9,444' },
    ],
  },
]

export default function Experience() {
  return (
    <div>
      {/* Page Header */}
      <section className="py-24 md:py-32 relative" style={{ paddingTop: 140 }}>
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(12,8,20,0.8) 0%, transparent 70%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 text-center relative z-10">
          <AnimatedHeading
            text="Work Experience"
            as="h1"
            className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight mb-6"
            delay={0.3}
          />
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="text-lg max-w-2xl mx-auto"
            style={{
              color: 'rgba(245, 240, 232, 0.75)',
              textShadow: '0 2px 8px rgba(0,0,0,0.7)',
            }}
          >
            9+ years of building, scaling, and fixing fintech & crypto products
          </motion.p>
        </div>
      </section>

      {/* Timeline */}
      <section className="pb-24 md:pb-32 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(12,8,20,0.5) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <div className="relative">
            {/* Central Line */}
            <div
              className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px md:-translate-x-px"
              style={{
                background: 'linear-gradient(to bottom, #d4a843, #a855f7, #00e5ff)',
                boxShadow: '0 0 15px rgba(168,85,247,0.3)',
              }}
            />

            {/* Job Entries */}
            <div className="space-y-16 md:space-y-24">
              {jobs.map((job, i) => (
                <ScrollReveal
                  key={i}
                  direction={job.side === 'left' ? 'left' : 'right'}
                  delay={0.1}
                >
                  <div
                    className={`relative flex flex-col md:flex-row ${
                      job.side === 'left' ? 'md:flex-row' : 'md:flex-row-reverse'
                    } items-start`}
                  >
                    {/* Timeline Node */}
                    <div className="absolute left-4 md:left-1/2 w-3 h-3 rounded-full -translate-x-1.5 md:-translate-x-1.5 z-10 mt-6"
                      style={{
                        background: '#d4a843',
                        boxShadow: '0 0 15px rgba(212, 168, 67, 0.6)',
                      }}
                    />

                    {/* Card Side */}
                    <div className={`pl-10 md:pl-0 md:w-1/2 ${job.side === 'left' ? 'md:pr-10' : 'md:pl-10'}`}>
                      <GlassCard accent={job.side === 'left' ? 'gold' : 'cyan'} intensity={6} className="p-6 md:p-8">
                        {/* Header */}
                        <div className="mb-4">
                          <h3 className="text-lg md:text-xl font-bold mb-1" style={{ color: '#f5f0e8', textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>{job.company}</h3>
                          <div className="flex flex-wrap items-center gap-2 text-sm">
                            <span style={{ color: 'rgba(245, 240, 232, 0.5)' }}>{job.role}</span>
                            <span style={{ color: 'rgba(245, 240, 232, 0.3)' }}>·</span>
                            <span className="font-mono text-xs" style={{ color: 'rgba(245, 240, 232, 0.5)' }}>
                              {job.period}
                            </span>
                          </div>
                          <div className="flex items-center gap-1 mt-2">
                            <MapPin size={12} style={{ color: '#00e5ff' }} />
                            <span
                              className="text-xs px-2 py-0.5 rounded-full"
                              style={{
                                background: 'rgba(0, 229, 255, 0.1)',
                                color: '#5ee8ff',
                                border: '1px solid rgba(0,229,255,0.2)',
                              }}
                            >
                              {job.location}
                            </span>
                          </div>
                        </div>

                        {/* Content */}
                        <div className="mb-4">{job.content}</div>

                        {/* Badges */}
                        {job.badges && (
                          <div className="flex flex-wrap gap-2 mb-4">
                            {job.badges.map((badge, bi) => (
                              <span
                                key={bi}
                                className="text-xs px-3 py-1 rounded-full font-medium"
                                style={{
                                  background: 'rgba(212, 168, 67, 0.15)',
                                  color: '#e8c86e',
                                  border: '1px solid rgba(212, 168, 67, 0.3)',
                                  textShadow: '0 1px 3px rgba(0,0,0,0.4)',
                                }}
                              >
                                {badge}
                              </span>
                            ))}
                          </div>
                        )}

                        {/* Highlights */}
                        {job.highlights && (
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                            {job.highlights.map((h, hi) => (
                              <div key={hi} className="text-center">
                                <div
                                  className="text-lg font-bold"
                                  style={{
                                    background: 'linear-gradient(135deg, #d4a843, #f0c76b)',
                                    WebkitBackgroundClip: 'text',
                                    WebkitTextFillColor: 'transparent',
                                    backgroundClip: 'text',
                                  }}
                                >
                                  {h.value}
                                </div>
                                <div className="text-xs mt-1" style={{ color: 'rgba(245, 240, 232, 0.55)' }}>
                                  {h.label}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </GlassCard>
                    </div>

                    {/* Image Side - opposite the card */}
                    <div className={`hidden md:block md:w-1/2 ${job.side === 'left' ? 'md:pl-10' : 'md:pr-10'}`}>
                      <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                        viewport={{ once: true }}
                        className="relative rounded-2xl overflow-hidden group"
                        style={{
                          boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
                          border: '1px solid rgba(255,255,255,0.06)',
                        }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent z-10 pointer-events-none" />
                        <img
                          src={job.image}
                          alt={job.company}
                          className="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105"
                          loading="lazy"
                        />
                        <div className="absolute bottom-3 left-3 z-20">
                          <span
                            className="text-xs px-2 py-1 rounded-md font-medium"
                            style={{
                              background: 'rgba(10,10,15,0.7)',
                              color: 'rgba(245,240,232,0.7)',
                              backdropFilter: 'blur(8px)',
                            }}
                          >
                            {job.company}
                          </span>
                        </div>
                      </motion.div>
                    </div>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
