import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Code, Wrench, Briefcase, Megaphone, Brain, Layers } from 'lucide-react'
import AnimatedHeading from '../components/AnimatedHeading'
import GlassCard from '../components/GlassCard'
import ScrollReveal from '../components/ScrollReveal'

gsap.registerPlugin(ScrollTrigger)

const skillCategories = [
  {
    icon: Code,
    name: 'Technical',
    accent: 'gold' as const,
    skills: [
      'JSON API Integrations', 'SQL', 'DevOps', 'WordPress', 'Figma', 'Canva',
      'UI/UX', 'QA', 'Prototype', 'UAT', 'Agile & Scrum SDLC',
      'APK/SDK/Web/Software development',
    ],
    proficiency: 95,
  },
  {
    icon: Wrench,
    name: 'Tools',
    accent: 'cyan' as const,
    skills: [
      'Clickup', 'Jira', 'Advanced Excel', 'Google Analytics',
      'Process Charts', 'GIS',
    ],
    proficiency: 90,
  },
  {
    icon: Briefcase,
    name: 'Business',
    accent: 'gold' as const,
    skills: [
      'GTM', 'Partnerships', 'Business Development',
      'Strategic Alliances', 'Counter-Negotiation',
    ],
    proficiency: 90,
  },
  {
    icon: Megaphone,
    name: 'Marketing',
    accent: 'cyan' as const,
    skills: [
      'Digital Marketing', 'Lead Gen', 'SEO', 'Branding',
      'Writing technical, promo, BRD, PRD and white-papers',
    ],
    proficiency: 85,
  },
  {
    icon: Brain,
    name: 'AI',
    accent: 'gold' as const,
    skills: [
      'GenAI', 'Integration & Middleware with LLMs',
      'Security on Federated Learning/Differential Privacy',
      'ETL & Data orchestration',
    ],
    proficiency: 80,
  },
  {
    icon: Layers,
    name: 'Product Management',
    accent: 'cyan' as const,
    skills: [
      'Product Roadmapping', 'MVP Development', 'User Research',
      'Competitive Analysis', 'Product Analytics', 'A/B Testing',
      'Feature Prioritization', 'Stakeholder Management',
      'Pricing Strategy', 'Product-Led Growth',
      'Release Management', 'OKR Planning',
    ],
    proficiency: 92,
  },
]

function ProficiencyBar({ label, value, accent }: { label: string; value: number; accent: 'gold' | 'cyan' }) {
  const barRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = barRef.current
    if (!el) return

    const inner = el.querySelector('.bar-inner') as HTMLElement
    if (!inner) return

    gsap.fromTo(
      inner,
      { width: '0%' },
      {
        width: `${value}%`,
        duration: 1.5,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      }
    )
  }, [value])

  return (
    <div ref={barRef} className="mb-5">
      <div className="flex justify-between mb-2">
        <span className="text-sm font-medium" style={{ color: 'rgba(245,240,232,0.9)', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>{label}</span>
        <span className="text-sm font-bold" style={{ color: accent === 'gold' ? '#e8c86e' : '#5ee8ff', textShadow: '0 0 8px rgba(0,0,0,0.5)' }}>
          {value}%
        </span>
      </div>
      <div
        className="h-2.5 rounded-full overflow-hidden"
        style={{ background: 'rgba(255, 255, 255, 0.06)', boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.3)' }}
      >
        <div
          className="bar-inner h-full rounded-full"
          style={{
            width: '0%',
            background: accent === 'gold'
              ? 'linear-gradient(to right, #d4a843, #f0c76b)'
              : 'linear-gradient(to right, #00e5ff, #66f0ff)',
            boxShadow: accent === 'gold'
              ? '0 0 12px rgba(212, 168, 67, 0.4)'
              : '0 0 12px rgba(0, 229, 255, 0.4)',
          }}
        />
      </div>
    </div>
  )
}

export default function Skills() {
  return (
    <div>
      {/* Page Header */}
      <section className="py-24 md:py-32 relative" style={{ paddingTop: 140 }}>
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(8,12,18,0.8) 0%, transparent 70%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 text-center relative z-10">
          <AnimatedHeading
            text="Skills & Expertise"
            as="h1"
            className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight mb-6"
            delay={0.3}
          />
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="text-lg max-w-2xl mx-auto"
            style={{
              color: 'rgba(245, 240, 232, 0.75)',
              textShadow: '0 2px 8px rgba(0,0,0,0.7)',
            }}
          >
            Technical depth meets commercial acumen
          </motion.p>
        </div>
      </section>

      {/* Skill Categories */}
      <section className="pb-16 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(8,12,18,0.6) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {skillCategories.map((category, i) => (
              <ScrollReveal key={i} delay={i * 0.1} direction="scale">
                <GlassCard accent={category.accent} intensity={8} className="p-8 h-full">
                  <category.icon
                    size={48}
                    className="mb-4"
                    style={{
                      color: category.accent === 'gold' ? '#d4a843' : '#00e5ff',
                      filter: `drop-shadow(0 0 14px ${category.accent === 'gold' ? 'rgba(212,168,67,0.4)' : 'rgba(0,229,255,0.4)'})`,
                    }}
                  />
                  <h3 className="text-xl md:text-2xl font-bold mb-5" style={{ color: '#f5f0e8', textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>{category.name}</h3>
                  <ul className="space-y-2.5">
                    {category.skills.map((skill, si) => (
                      <li key={si} className="flex items-start gap-3">
                        <span
                          className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                          style={{
                            background: category.accent === 'gold' ? '#d4a843' : '#00e5ff',
                            boxShadow: `0 0 6px ${category.accent === 'gold' ? 'rgba(212,168,67,0.5)' : 'rgba(0,229,255,0.5)'}`,
                          }}
                        />
                        <span className="text-sm" style={{ color: 'rgba(245, 240, 232, 0.85)', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
                          {skill}
                        </span>
                      </li>
                    ))}
                  </ul>
                </GlassCard>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Proficiency Visualization */}
      <section className="py-20 md:py-28 relative">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(8,12,18,0.65) 0%, transparent 80%)',
          }}
        />
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <ScrollReveal>
            <h2
              className="text-3xl md:text-4xl font-bold mb-10 text-center"
              style={{
                background: 'linear-gradient(135deg, #d4a843, #f5f0e8, #00e5ff)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              Proficiency Depth
            </h2>
          </ScrollReveal>

          <div className="max-w-2xl mx-auto">
            <GlassCard className="p-8 md:p-10">
              {skillCategories.map((cat, i) => (
                <ProficiencyBar
                  key={i}
                  label={cat.name}
                  value={cat.proficiency}
                  accent={cat.accent}
                />
              ))}
            </GlassCard>
          </div>
        </div>
      </section>
    </div>
  )
}
