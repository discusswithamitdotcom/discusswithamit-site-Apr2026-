import { Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { useEffect } from 'react'
import BackgroundSwitcher from './components/BackgroundSwitcher'
import { BackgroundProvider, useBackground } from './components/BackgroundContext'
import Navbar from './components/Navbar'
import WhatsAppButton from './components/WhatsAppButton'
import Footer from './components/Footer'
import Home from './pages/Home'
import About from './pages/About'
import Experience from './pages/Experience'
import Skills from './pages/Skills'
import Contact from './pages/Contact'

function PageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5, ease: [0.32, 0, 0.67, 0] }}
      style={{ position: 'relative', zIndex: 10 }}
    >
      {children}
    </motion.div>
  )
}

function RouteSync() {
  const location = useLocation()
  const { setRoute } = useBackground()

  useEffect(() => {
    setRoute(location.pathname)
  }, [location.pathname, setRoute])

  return null
}

function AppContent() {
  const location = useLocation()

  return (
    <div className="noise-overlay">
      <RouteSync />
      {/* Page-specific 3D background */}
      <BackgroundSwitcher />

      {/* Vignette overlay for readability */}
      <div
        style={{
          position: 'fixed',
          inset: 0,
          zIndex: 1,
          pointerEvents: 'none',
          background: 'radial-gradient(ellipse at center, transparent 0%, transparent 40%, rgba(10,10,15,0.6) 100%)',
        }}
      />

      {/* Bottom scrim for text near footer */}
      <div
        style={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          height: '40vh',
          zIndex: 1,
          pointerEvents: 'none',
          background: 'linear-gradient(to top, rgba(10,10,15,0.85), transparent)',
        }}
      />

      {/* Navigation */}
      <Navbar />

      {/* Main content with page transitions */}
      <main style={{ position: 'relative', zIndex: 10 }}>
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<PageWrapper><Home /></PageWrapper>} />
            <Route path="/about" element={<PageWrapper><About /></PageWrapper>} />
            <Route path="/experience" element={<PageWrapper><Experience /></PageWrapper>} />
            <Route path="/skills" element={<PageWrapper><Skills /></PageWrapper>} />
            <Route path="/contact" element={<PageWrapper><Contact /></PageWrapper>} />
          </Routes>
        </AnimatePresence>
      </main>

      {/* WhatsApp Floating Button */}
      <WhatsAppButton />

      {/* Footer */}
      <Footer />
    </div>
  )
}

export default function App() {
  return (
    <BackgroundProvider>
      <AppContent />
    </BackgroundProvider>
  )
}
